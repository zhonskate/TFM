"""Tests for the dice package"""
