
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.5'
version = '1.18.5'
full_version = '1.18.5'
git_revision = '32f514f546733ae1960077d2be93be970f4e13ef'
release = True

if not release:
    version = full_version
