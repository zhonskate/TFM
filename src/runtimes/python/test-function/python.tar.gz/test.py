import dice
roll = dice.roll('3d20')
print(roll)